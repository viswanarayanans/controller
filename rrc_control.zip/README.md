# controller
Nonlinear controller for drones

Place this controller along with your rotors packages. Build it.
Change the path to yaml files and controller in your launch file. Launch it.
